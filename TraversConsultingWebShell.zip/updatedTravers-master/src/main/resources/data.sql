insert ignore INTO `role` VALUES (1,'ADMIN');
insert ignore INTO `role` VALUES (2,'USER');